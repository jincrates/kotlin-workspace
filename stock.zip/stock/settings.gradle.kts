rootProject.name = "stock"
